import LoginPage from "./Pages/Login/LoginPage";

function App() {
  return <LoginPage />;
}

export default App;
