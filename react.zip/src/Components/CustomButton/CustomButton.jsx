export default function CustomButton({ children, ...other }) {
  return (
    <button
      className="btn btn-outline-success btn-lg btn-login"
      style={{ paddingLeft: "2.5rem", paddingRight: "2.5rem" }}
      {...other}
    >
      <b>{children}</b>
    </button>
  );
}
