export default function CustomInput({ handleChange, type, label, ...other }) {
  return (
    <div className="form-outline mb-4">
      <div className="row row-class">
        <div className="col-lg-1 space-up ">
          <i className="fas fa-envelope "></i>
        </div>
        <div className="col-lg-8 space-left">
          <input
            type={type}
            onChange={handleChange}
            className="form-control form-control-lg"
            placeholder={label}
            {...other}
          />
        </div>
      </div>
    </div>
  );
}
